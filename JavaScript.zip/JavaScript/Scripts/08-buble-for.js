"use strict"

//Bucle for
// Buble es una estructura de control que se repite varias veces

for(var i = 0 ; i<=100; i++){
    if(i==0){
        console.log("Inicio del bucle")
    }
    console.log(i);
    if(i == 100){
        console.log("llegaste al final de bucle")
    }
    //Debugger para la ejecucion del codigo justo en el sitio de su colocacion
    debugger;
}