// Esto es un comentario de una sola linea
/* Esto es un comentario 
multi linea */
document.write("Hola mundo desde fichero externo");
console.log("muestra esto en la consola");
console.log(95*2);
 