'use strict'
//Variables
// Una variable es un contenedor de información

var pais  = "Mexico";
var continente = "LatinoAmerica";
var antiguedad = 2022;
var pais_y_continente = pais + " " + continente; 
let prueba = "hola";
alert(prueba);
pais= "Mexico";
continente = "LatinoAmerica";
// la coma dentro de un console.log se ocupa para poder juntar varialbes mas no unirlas
console.log(continente,pais, antiguedad);

alert(pais_y_continente);