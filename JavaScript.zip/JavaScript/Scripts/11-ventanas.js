"use strict"

//Aleta
alert("Hola");

//Confirmacion
//el comando confirm permite aceptar o negar una alerta
var resultado = confirm("¿Estas seguro de querer continuar?");
console.log(resultado);

//ingreso de informacion
//prompt(pregunta,valorxdefecto)
var resultado2 = prompt("¿Que edad tienes?",18);
console.log(parseFloat(resultado2));