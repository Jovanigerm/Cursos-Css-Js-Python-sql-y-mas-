"use strict"

var numero= 0;

while(numero <= 100){
    if(numero==0){
        console.log("Inicio del bucle while");
    }
    console.log(numero);
    if(numero==100){
        console.log("Fin del bucle while");
    }
    numero++;
}