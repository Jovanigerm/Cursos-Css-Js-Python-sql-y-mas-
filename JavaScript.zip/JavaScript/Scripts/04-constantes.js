"use strict"
// Constante
// Variable , pero su valor no puede cambiar
var web = "http://google.com";
const ip = "192.88.0.12";
web = "http://youtube";
//ip ="183.12.0.12";
console.log(web,ip);